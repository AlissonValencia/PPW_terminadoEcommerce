package com.productos.seguridad;

import com.productos.datos.Conexion;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Bitacora {
    private int idLog;
    private int idUsuario;
    private String accion;
    private Timestamp fechaHora;
    private String descripcion;

    // Constructor vacío
    public Bitacora() {}

    // Constructor con parámetros
    public Bitacora(int idLog, int idUsuario, String accion, Timestamp fechaHora, String descripcion) {
        this.idLog = idLog;
        this.idUsuario = idUsuario;
        this.accion = accion;
        this.fechaHora = fechaHora;
        this.descripcion = descripcion;
    }

    // Getters y Setters
    public int getIdLog() { return idLog; }
    public void setIdLog(int idLog) { this.idLog = idLog; }
    public int getIdUsuario() { return idUsuario; }
    public void setIdUsuario(int idUsuario) { this.idUsuario = idUsuario; }
    public String getAccion() { return accion; }
    public void setAccion(String accion) { this.accion = accion; }
    public Timestamp getFechaHora() { return fechaHora; }
    public void setFechaHora(Timestamp fechaHora) { this.fechaHora = fechaHora; }
    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    /**
     * Registra una acción en la bitácora del sistema.
     * @param idUsuario El ID del usuario que realiza la acción.
     * @param accion La acción realizada (ej. "Inicio de Sesión", "Producto Agregado").
     * @param descripcion Una descripción detallada de la acción.
     * @return true si la acción se registró exitosamente, false en caso contrario.
     */
    public boolean registrarAccion(int idUsuario, String accion, String descripcion) {
        String sql = "INSERT INTO tb_bitacora (id_us, accion, fecha_hora, descripcion) VALUES (?, ?, ?, ?)";
        Conexion con = new Conexion();
        boolean resultado = false;
        PreparedStatement ps = null; // Declarar aquí para asegurar el cierre en finally
        try {
            Connection connection = con.getConexion();
            if (connection == null) {
                System.out.println("ERROR: [Bitacora.java] registrarAccion - No se pudo obtener la conexión a la base de datos.");
                return false;
            }
            ps = connection.prepareStatement(sql);
            ps.setInt(1, idUsuario);
            ps.setString(2, accion);
            ps.setTimestamp(3, new Timestamp(System.currentTimeMillis()));
            ps.setString(4, descripcion);
            int filasAfectadas = ps.executeUpdate();
            resultado = (filasAfectadas > 0);
            if (resultado) {
                System.out.println("DEBUG: [Bitacora.java] Acción '" + accion + "' registrada para usuario ID: " + idUsuario);
            } else {
                System.out.println("ERROR: [Bitacora.java] Fallo al registrar acción '" + accion + "' para usuario ID: " + idUsuario + ". No se afectaron filas.");
            }
        } catch (SQLException e) {
            System.out.println("ERROR: [Bitacora.java] Error SQL al registrar acción en bitácora: " + e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            System.out.println("ERROR: [Bitacora.java] Error inesperado al registrar acción en bitácora: " + e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                if (ps != null) ps.close();
            } catch (SQLException e) {
                System.out.println("ERROR: [Bitacora.java] Error al cerrar PreparedStatement en Bitacora: " + e.getMessage());
                e.printStackTrace();
            }
            con.cerrarConexion(); // Asegurarse de que la conexión se cierre
        }
        return resultado;
    }

    /**
     * Consulta todas las acciones de la bitácora, incluyendo el nombre del usuario.
     * @return Una lista de objetos Bitacora, ordenados por fecha y hora descendente.
     */
    public List<Bitacora> consultarBitacora() {
        List<Bitacora> logs = new ArrayList<>();
        // Se une con tb_usuario para obtener el nombre del usuario y mostrarlo en la descripción si se desea.
        // Aquí se recupera el nombre_us para un uso futuro si es necesario en el JSP.
        String sql = "SELECT b.id_log, b.id_us, u.nombre_us, b.accion, b.fecha_hora, b.descripcion " +
                     "FROM tb_bitacora b JOIN tb_usuario u ON b.id_us = u.id_us ORDER BY b.fecha_hora DESC";
        Conexion con = new Conexion();
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            Connection connection = con.getConexion();
            if (connection == null) {
                System.out.println("ERROR: [Bitacora.java] consultarBitacora - No se pudo obtener la conexión a la base de datos.");
                return logs;
            }
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Bitacora log = new Bitacora(
                    rs.getInt("id_log"),
                    rs.getInt("id_us"),
                    rs.getString("accion"),
                    rs.getTimestamp("fecha_hora"),
                    rs.getString("descripcion")
                );
                logs.add(log);
            }
            System.out.println("DEBUG: [Bitacora.java] Bitácora consultada exitosamente. Registros encontrados: " + logs.size());
        } catch (SQLException e) {
            System.out.println("ERROR: [Bitacora.java] Error SQL al consultar bitácora: " + e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            System.out.println("ERROR: [Bitacora.java] Error inesperado al consultar bitácora: " + e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
            } catch (SQLException e) {
                System.out.println("ERROR: [Bitacora.java] Error al cerrar recursos en Bitacora.consultarBitacora(): " + e.getMessage());
                e.printStackTrace();
            }
            con.cerrarConexion();
        }
        return logs;
    }
}
