package com.productos.negocio;

import com.productos.datos.Conexion;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DetalleOrden {
    private int idDetalle; // Coincide con id_detalle
    private int idOrden;
    private int idProducto; // Coincide con id_pr
    private String nombreProducto; // Para mostrar el nombre del producto directamente
    private int cantidad;
    private double precioUnitario;

    // Constructor vacío
    public DetalleOrden() {}

    // Constructor con parámetros (para construir objetos desde la DB)
    // Se eliminó 'totalDetalle' del constructor ya que es un valor calculado
    public DetalleOrden(int idDetalle, int idOrden, int idProducto, String nombreProducto, int cantidad, double precioUnitario) {
        this.idDetalle = idDetalle;
        this.idOrden = idOrden;
        this.idProducto = idProducto;
        this.nombreProducto = nombreProducto;
        this.cantidad = cantidad;
        this.precioUnitario = precioUnitario;
    }

    // Getters
    public int getIdDetalle() { return idDetalle; }
    public int getIdOrden() { return idOrden; }
    public int getIdProducto() { return idProducto; }
    public String getNombreProducto() { return nombreProducto; }
    public int getCantidad() { return cantidad; }
    public double getPrecioUnitario() { return precioUnitario; }

    // Método para calcular el total del detalle (no se lee de la DB)
    public double getTotalDetalle() {
        return this.cantidad * this.precioUnitario;
    }

    // Setters (puedes añadir si los necesitas, pero para esta funcionalidad no son estrictamente necesarios aquí)
    public void setIdDetalle(int idDetalle) { this.idDetalle = idDetalle; }
    public void setIdOrden(int idOrden) { this.idOrden = idOrden; }
    public void setIdProducto(int idProducto) { this.idProducto = idProducto; }
    public void setNombreProducto(String nombreProducto) { this.nombreProducto = nombreProducto; }
    public void setCantidad(int cantidad) { this.cantidad = cantidad; }
    public void setPrecioUnitario(double precioUnitario) { this.precioUnitario = precioUnitario; }


    // Método para insertar un detalle de orden
    // Se eliminó 'totalDetalle' de los parámetros y de la sentencia SQL
    public boolean insertarDetalleOrden(int idOrden, int idProducto, int cantidad, double precioUnitario) {
        // El total_detalle se calcula en el momento de la inserción si la columna existiera,
        // pero como tu tabla no la tiene, insertamos solo las columnas que sí tienes.
        String sql = "INSERT INTO tb_detalle_orden (id_orden, id_pr, cantidad, precio_unitario) VALUES (?, ?, ?, ?)";
        Conexion con = new Conexion();
        boolean resultado = false;
        try (PreparedStatement ps = con.getConexion().prepareStatement(sql)) {
            ps.setInt(1, idOrden);
            ps.setInt(2, idProducto); // Ahora usa id_pr
            ps.setInt(3, cantidad);
            ps.setDouble(4, precioUnitario);
            int filasAfectadas = ps.executeUpdate();
            resultado = (filasAfectadas > 0);
        } catch (SQLException e) {
            System.out.println("Error al insertar detalle de orden: " + e.getMessage());
            e.printStackTrace(); // Imprime el stack trace para depuración
        } finally {
            con.cerrarConexion();
        }
        return resultado;
    }

    // Método para obtener los detalles de una orden específica
    public List<DetalleOrden> obtenerDetallesPorOrden(int idOrden) {
        List<DetalleOrden> detalles = new ArrayList<>();
        Conexion con = new Conexion();
        ResultSet rs = null;
        PreparedStatement ps = null;

        // La consulta se ajusta a tus nombres de columna (id_detalle, id_pr)
        // y selecciona p.nombre_pr de tb_producto
        String sql = "SELECT " +
                     "do.id_detalle, " + // Se usa id_detalle
                     "do.id_orden, " +
                     "do.id_pr, " +     // Se usa id_pr
                     "p.nombre_pr, " +
                     "do.cantidad, " +
                     "do.precio_unitario " +
                     "FROM tb_detalle_orden do " +
                     "JOIN tb_producto p ON do.id_pr = p.id_pr " + // Join con id_pr
                     "WHERE do.id_orden = ?";

        try {
            ps = con.getConexion().prepareStatement(sql);
            ps.setInt(1, idOrden);
            rs = ps.executeQuery();

            while (rs.next()) {
                DetalleOrden detalle = new DetalleOrden(
                    rs.getInt("id_detalle"), // Lee id_detalle
                    rs.getInt("id_orden"),
                    rs.getInt("id_pr"),     // Lee id_pr
                    rs.getString("nombre_pr"),
                    rs.getInt("cantidad"),
                    rs.getDouble("precio_unitario")
                );
                detalles.add(detalle);
            }
        } catch (SQLException e) {
            System.out.println("Error al obtener detalles de la orden: " + e.getMessage());
            e.printStackTrace(); // Para ver el stack trace completo del error
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                con.cerrarConexion(); // Asegúrate de que este método cierra la conexión
            } catch (SQLException e) {
                System.out.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
        return detalles;
    }

}
