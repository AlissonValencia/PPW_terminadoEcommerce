package com.productos.negocio;

import com.productos.datos.Conexion;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Orden {
    private int idOrden;
    private int idUsuario;
    private Timestamp fechaOrden;
    private double total;
    private String estadoPago; // Ej: "Pendiente", "Pagado", "Fallido"

    // Constructor vacío
    public Orden() {}

    // Constructor con parámetros
    public Orden(int idOrden, int idUsuario, Timestamp fechaOrden, double total, String estadoPago) {
        this.idOrden = idOrden;
        this.idUsuario = idUsuario;
        this.fechaOrden = fechaOrden;
        this.total = total;
        this.estadoPago = estadoPago;
    }

    // Getters y Setters
    public int getIdOrden() { return idOrden; }
    public void setIdOrden(int idOrden) { this.idOrden = idOrden; }
    public int getIdUsuario() { return idUsuario; }
    public void setIdUsuario(int idUsuario) { this.idUsuario = idUsuario; }
    public Timestamp getFechaOrden() { return fechaOrden; }
    public void setFechaOrden(Timestamp fechaOrden) { this.fechaOrden = fechaOrden; }
    public double getTotal() { return total; }
    public void setTotal(double total) { this.total = total; }
    public String getEstadoPago() { return estadoPago; }
    public void setEstadoPago(String estadoPago) { this.estadoPago = estadoPago; }

    // Método para insertar una nueva orden y obtener su ID generado
    public int insertarOrden(int idUsuario, double total, String estadoPago) {
        String sql = "INSERT INTO tb_orden (id_us, fecha_orden, total_orden, estado_pago) VALUES (?, ?, ?, ?)";
        Conexion con = new Conexion();
        int idGenerado = -1;
        try (PreparedStatement ps = con.getConexion().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, idUsuario);
            ps.setTimestamp(2, new Timestamp(System.currentTimeMillis()));
            ps.setDouble(3, total);
            ps.setString(4, estadoPago);
            int filasAfectadas = ps.executeUpdate();
            if (filasAfectadas > 0) {
                try (ResultSet rs = ps.getGeneratedKeys()) {
                    if (rs.next()) {
                        idGenerado = rs.getInt(1);
                    }
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al insertar orden: " + e.getMessage());
        } finally {
            con.cerrarConexion();
        }
        return idGenerado;
    }

    // Método para obtener todas las órdenes de un usuario
    public List<Orden> obtenerOrdenesPorUsuario(int idUsuario) {
        List<Orden> ordenes = new ArrayList<>();
        String sql = "SELECT id_orden, id_us, fecha_orden, total_orden, estado_pago FROM tb_orden WHERE id_us = ? ORDER BY fecha_orden DESC";
        Conexion con = new Conexion();
        try (PreparedStatement ps = con.getConexion().prepareStatement(sql)) {
            ps.setInt(1, idUsuario);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Orden orden = new Orden(
                        rs.getInt("id_orden"),
                        rs.getInt("id_us"),
                        rs.getTimestamp("fecha_orden"),
                        rs.getDouble("total_orden"),
                        rs.getString("estado_pago")
                    );
                    ordenes.add(orden);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al obtener órdenes por usuario: " + e.getMessage());
        } finally {
            con.cerrarConexion();
        }
        return ordenes;
    }
}
