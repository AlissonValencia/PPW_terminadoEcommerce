package com.productos.seguridad;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.productos.datos.Conexion;

public class Usuario {

    private int id;
    private int perfil;
    private int estadoCivil;
    private String cedula;
    private String nombre;
    private String correo;
    private String clave;
    private int estadoUsuario; // Nuevo campo para el estado del usuario (ej: 0=activo, 1=bloqueado)

    // Getters y Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getPerfil() { return perfil; }
    public void setPerfil(int perfil) { this.perfil = perfil; }

    public int getEstadoCivil() { return estadoCivil; }
    public void setEstadoCivil(int estadoCivil) { this.estadoCivil = estadoCivil; }

    public String getCedula() { return cedula; }
    public void setCedula(String cedula) { this.cedula = cedula; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getCorreo() { return correo; }
    public void setCorreo(String correo) { this.correo = correo; }

    public String getClave() { return clave; }
    public void setClave(String clave) { this.clave = clave; }

    public int getEstadoUsuario() { return estadoUsuario; }
    public void setEstadoUsuario(int estadoUsuario) { this.estadoUsuario = estadoUsuario; }

    /**
     * Verifica las credenciales de un usuario para el inicio de sesión.
     * También verifica si el usuario está bloqueado.
     * @param ncorreo El correo electrónico del usuario.
     * @param nclave La clave del usuario.
     * @return true si el usuario existe y las credenciales son correctas y no está bloqueado, false en caso contrario.
     */
    public boolean verificarUsuario(String ncorreo, String nclave) {
        boolean existe = false;

        String correoLimpio = (ncorreo != null) ? ncorreo.trim() : "";
        String claveLimpia = (nclave != null) ? nclave.trim() : "";

        if (correoLimpio.isEmpty() || claveLimpia.isEmpty()) {
            System.out.println("DEBUG: [Usuario.java] verificarUsuario - Correo o clave de entrada nulos/vacíos.");
            return false;
        }

        String sql = "SELECT id_us, nombre_us, cedula_us, correo_us, id_per, id_est, estado_us FROM tb_usuario WHERE correo_us = ? AND clave_us = ?";
        Conexion con = new Conexion();
        ResultSet rs = null; // Declarar ResultSet fuera del try-with-resources para poder cerrarlo en finally
        PreparedStatement ps = null; // Declarar PreparedStatement para cerrar en finally

        System.out.println("DEBUG: [Usuario.java] verificarUsuario - Intentando verificar usuario: " + correoLimpio);

        try {
            Connection connection = con.getConexion(); // Obtener la conexión
            if (connection == null) {
                System.out.println("ERROR: [Usuario.java] verificarUsuario - No se pudo obtener la conexión a la base de datos.");
                return false;
            }
            ps = connection.prepareStatement(sql); // Preparar la sentencia
            ps.setString(1, correoLimpio);
            ps.setString(2, claveLimpia);

            rs = ps.executeQuery(); // Ejecutar la consulta

            if (rs.next()) {
                this.id = rs.getInt("id_us");
                this.nombre = rs.getString("nombre_us");
                this.cedula = rs.getString("cedula_us");
                this.correo = rs.getString("correo_us");
                this.perfil = rs.getInt("id_per");
                this.estadoCivil = rs.getInt("id_est");
                this.estadoUsuario = rs.getInt("estado_us");

                if (this.estadoUsuario == 1) { // Asumiendo 1 = bloqueado
                    existe = false;
                    System.out.println("DEBUG: [Usuario.java] verificarUsuario - Usuario bloqueado: " + this.correo);
                } else {
                    existe = true;
                    System.out.println("DEBUG: [Usuario.java] verificarUsuario - Usuario verificado exitosamente: " + this.nombre);
                }
            } else {
                System.out.println("DEBUG: [Usuario.java] verificarUsuario - Credenciales incorrectas para: " + correoLimpio);
            }
        } catch (SQLException e) {
            System.out.println("ERROR: [Usuario.java] verificarUsuario - Error SQL: " + e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            System.out.println("ERROR: [Usuario.java] verificarUsuario - Error inesperado: " + e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close(); // Cerrar ResultSet
                if (ps != null) ps.close(); // Cerrar PreparedStatement
            } catch (SQLException e) {
                System.out.println("ERROR: [Usuario.java] verificarUsuario - Error al cerrar recursos: " + e.getMessage());
                e.printStackTrace();
            }
            con.cerrarConexion(); // Cerrar la conexión
        }
        return existe;
    }

    /**
     * Inserta un nuevo cliente en la base de datos con un perfil fijo (2).
     * @return Un mensaje de éxito o error.
     */
    public String ingresarCliente() {
        String result = "";
        Conexion con = new Conexion();
        PreparedStatement pr = null;
        String sql = "INSERT INTO tb_usuario (id_per, id_est,nombre_us,cedula_us,correo_us,clave_us, estado_us) VALUES (?, ?, ?, ?, ?, ?, 0)"; // Estado activo por defecto

        System.out.println("DEBUG: [Usuario.java] ingresarCliente - Intentando registrar nuevo cliente: " + this.correo);

        try {
            Connection connection = con.getConexion();
            if (connection == null) {
                System.out.println("ERROR: [Usuario.java] ingresarCliente - No se pudo obtener la conexión a la base de datos.");
                return "Error: No hay conexión a la base de datos.";
            }
            pr = connection.prepareStatement(sql);
            pr.setInt(1, 2); // perfil cliente fijo
            pr.setInt(2, this.estadoCivil);
            pr.setString(3, this.nombre != null ? this.nombre.trim() : null);
            pr.setString(4, this.cedula != null ? this.cedula.trim() : null);
            pr.setString(5, this.correo != null ? this.correo.trim() : null);
            pr.setString(6, this.clave != null ? this.clave.trim() : null);

            int filas = pr.executeUpdate();
            result = (filas == 1) ? "Inserción correcta" : "Error en inserción";
            System.out.println("DEBUG: [Usuario.java] ingresarCliente - Resultado: " + result);

        } catch (SQLException ex) {
            // Manejar específicamente la violación de unicidad si el correo ya existe
            if (ex.getSQLState().equals("23505")) { // Código SQLState para violación de unicidad
                result = "Error: El correo electrónico ya está registrado.";
                System.out.println("ERROR: [Usuario.java] ingresarCliente - Error SQL (correo duplicado): " + ex.getMessage());
            } else {
                result = "Error SQL: " + ex.getMessage();
                System.out.println("ERROR: [Usuario.java] ingresarCliente - Error SQL: " + ex.getMessage());
            }
            ex.printStackTrace();
        } catch (Exception ex) {
            result = "Error inesperado: " + ex.getMessage();
            System.out.println("ERROR: [Usuario.java] ingresarCliente - Error inesperado: " + ex.getMessage());
            ex.printStackTrace();
        } finally {
            try {
                if (pr != null) pr.close();
            } catch (SQLException e) {
                System.out.println("ERROR: [Usuario.java] ingresarCliente - Error cerrando PreparedStatement: " + e.getMessage());
                e.printStackTrace();
            }
            con.cerrarConexion();
        }
        return result;
    }

    /**
     * Inserta un nuevo usuario en la base de datos con un perfil dinámico.
     * @return true si el usuario se insertó correctamente, false en caso contrario.
     */
    public boolean ingresarUsuario() {
        boolean respuesta = false;
        Conexion con = new Conexion();
        PreparedStatement pr = null;
        String sql = "INSERT INTO tb_usuario (id_per, id_est,nombre_us,cedula_us,correo_us,clave_us, estado_us) VALUES (?, ?, ?, ?, ?, ?, 0)"; // Estado activo por defecto

        System.out.println("DEBUG: [Usuario.java] ingresarUsuario - Intentando registrar nuevo usuario: " + this.correo);

        try {
            Connection connection = con.getConexion();
            if (connection == null) {
                System.out.println("ERROR: [Usuario.java] ingresarUsuario - No se pudo obtener la conexión a la base de datos.");
                return false;
            }
            pr = connection.prepareStatement(sql);
            pr.setInt(1, this.perfil);
            pr.setInt(2, this.estadoCivil);
            pr.setString(3, this.nombre != null ? this.nombre.trim() : null);
            pr.setString(4, this.cedula != null ? this.cedula.trim() : null);
            pr.setString(5, this.correo != null ? this.correo.trim() : null);
            pr.setString(6, this.clave != null ? this.clave.trim() : null);

            respuesta = pr.executeUpdate() == 1;
            System.out.println("DEBUG: [Usuario.java] ingresarUsuario - Resultado: " + respuesta);

        } catch (SQLException ex) {
            // Manejar específicamente la violación de unicidad si el correo ya existe
            if (ex.getSQLState().equals("23505")) {
                System.out.println("ERROR: [Usuario.java] ingresarUsuario - Error SQL (correo duplicado): " + ex.getMessage());
            } else {
                System.out.println("ERROR: [Usuario.java] ingresarUsuario - Error SQL: " + ex.getMessage());
            }
            ex.printStackTrace();
            respuesta = false; // Asegurar que la respuesta sea false en caso de error
        } catch (Exception ex) {
            System.out.println("ERROR: [Usuario.java] ingresarUsuario - Error inesperado: " + ex.getMessage());
            ex.printStackTrace();
            respuesta = false; // Asegurar que la respuesta sea false en caso de error
        } finally {
            try {
                if (pr != null) pr.close();
            } catch (SQLException e) {
                System.out.println("ERROR: [Usuario.java] ingresarUsuario - Error cerrando PreparedStatement: " + e.getMessage());
                e.printStackTrace();
            }
            con.cerrarConexion();
        }
        return respuesta;
    }

    /**
     * Verifica si la clave proporcionada coincide con la clave almacenada para el correo del usuario.
     * @param aclave La clave a verificar.
     * @return true si la clave es correcta, false en caso contrario.
     */
    public boolean verificarClave(String aclave) {
        if (aclave == null || this.correo == null || aclave.trim().isEmpty() || this.correo.trim().isEmpty()) {
            System.out.println("DEBUG: [Usuario.java] verificarClave - Datos de entrada nulos o vacíos.");
            return false;
        }

        boolean respuesta = false;
        String sql = "SELECT clave_us FROM tb_usuario WHERE correo_us = ? AND clave_us = ?";
        Conexion clsCon = new Conexion();
        ResultSet rs = null;
        PreparedStatement pr = null;

        System.out.println("DEBUG: [Usuario.java] verificarClave - Verificando clave para correo: " + this.correo);

        try {
            Connection con = clsCon.getConexion();
            if (con == null) {
                System.out.println("ERROR: [Usuario.java] verificarClave - No se pudo obtener la conexión a la base de datos.");
                return false;
            }
            pr = con.prepareStatement(sql);

            pr.setString(1, this.correo.trim());
            pr.setString(2, aclave.trim());

            rs = pr.executeQuery();
            if (rs.next()) {
                respuesta = true;
                System.out.println("DEBUG: [Usuario.java] verificarClave - Clave actual correcta.");
            } else {
                respuesta = false; // Asegurar que sea false si no encuentra
                System.out.println("DEBUG: [Usuario.java] verificarClave - Clave actual incorrecta o usuario no encontrado.");
            }

        } catch (SQLException ex) {
            System.out.println("ERROR: [Usuario.java] verificarClave - Error SQL: " + ex.getMessage());
            ex.printStackTrace();
        } catch (Exception ex) {
            System.out.println("ERROR: [Usuario.java] verificarClave - Error inesperado: " + ex.getMessage());
            ex.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (pr != null) pr.close();
            } catch (SQLException e) {
                System.out.println("ERROR: [Usuario.java] verificarClave - Error al cerrar recursos: " + e.getMessage());
                e.printStackTrace();
            }
            clsCon.cerrarConexion();
        }
        return respuesta;
    }

    /**
     * Compara si dos cadenas de texto (claves) son idénticas.
     * @param clave1 Primera clave.
     * @param clave2 Segunda clave.
     * @return true si las claves coinciden, false en caso contrario.
     */
    public boolean coincidirClaves(String clave1, String clave2) {
        if (clave1 != null && clave2 != null && clave1.equals(clave2)) {
            System.out.println("DEBUG: [Usuario.java] coincidirClaves - Las claves coinciden.");
            return true;
        }
        System.out.println("DEBUG: [Usuario.java] coincidirClaves - Las claves NO coinciden.");
        return false;
    }

    /**
     * Cambia la clave de un usuario en la base de datos.
     * @param ncorreo El correo electrónico del usuario.
     * @param nclave La nueva clave.
     * @return true si la clave se actualizó exitosamente, false en caso contrario.
     */
    public boolean cambiarClave(String ncorreo, String nclave) {
        if (ncorreo == null || nclave == null || ncorreo.trim().isEmpty() || nclave.trim().isEmpty()) {
            System.out.println("DEBUG: [Usuario.java] cambiarClave - Correo o nueva clave nulos/vacíos.");
            return false;
        }

        boolean respuesta = false;
        String sql = "UPDATE tb_usuario SET clave_us = ? WHERE correo_us = ?";
        Conexion clsCon = new Conexion();
        PreparedStatement pr = null;

        System.out.println("DEBUG: [Usuario.java] cambiarClave - Cambiando clave para correo: " + ncorreo);

        try {
            Connection con = clsCon.getConexion();
            if (con == null) {
                System.out.println("ERROR: [Usuario.java] cambiarClave - No se pudo obtener la conexión a la base de datos.");
                return false;
            }
            pr = con.prepareStatement(sql);
            pr.setString(1, nclave.trim());
            pr.setString(2, ncorreo.trim());

            int filasAfectadas = pr.executeUpdate();
            respuesta = (filasAfectadas == 1); // True si se afectó exactamente 1 fila
            if (respuesta) {
                System.out.println("DEBUG: [Usuario.java] cambiarClave - Clave actualizada exitosamente.");
            } else {
                System.out.println("DEBUG: [Usuario.java] cambiarClave - No se pudo actualizar la clave. Filas afectadas: " + filasAfectadas);
            }

        } catch (SQLException ex) {
            System.out.println("ERROR: [Usuario.java] cambiarClave - Error SQL: " + ex.getMessage());
            ex.printStackTrace();
        } catch (Exception ex) {
            System.out.println("ERROR: [Usuario.java] cambiarClave - Error inesperado: " + ex.getMessage());
            ex.printStackTrace();
        } finally {
            try {
                if (pr != null) pr.close();
            } catch (SQLException e) {
                System.out.println("ERROR: [Usuario.java] cambiarClave - Error cerrando PreparedStatement: " + e.getMessage());
                e.printStackTrace();
            }
            clsCon.cerrarConexion();
        }
        return respuesta;
    }

    /**
     * Obtiene el correo electrónico de un usuario a partir de su ID.
     * @param id El ID del usuario.
     * @return El correo electrónico del usuario o null si no se encuentra.
     */
    public String getCorreoById(int id) {
        String email = null;
        String sql = "SELECT correo_us FROM tb_usuario WHERE id_us = ?";
        Conexion con = new Conexion();
        ResultSet rs = null;
        PreparedStatement ps = null;

        System.out.println("DEBUG: [Usuario.java] getCorreoById - Buscando correo para ID: " + id);

        try {
            Connection connection = con.getConexion();
            if (connection == null) {
                System.out.println("ERROR: [Usuario.java] getCorreoById - No se pudo obtener la conexión a la base de datos.");
                return null;
            }
            ps = connection.prepareStatement(sql);
            ps.setInt(1, id);
            rs = ps.executeQuery();
            if (rs.next()) {
                email = rs.getString("correo_us");
                System.out.println("DEBUG: [Usuario.java] getCorreoById - Correo encontrado: " + email);
            } else {
                System.out.println("DEBUG: [Usuario.java] getCorreoById - No se encontró correo para ID: " + id);
            }
        } catch (SQLException e) {
            System.out.println("ERROR: [Usuario.java] getCorreoById - Error SQL: " + e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            System.out.println("ERROR: [Usuario.java] getCorreoById - Error inesperado: " + e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
            } catch (SQLException e) {
                System.out.println("ERROR: [Usuario.java] getCorreoById - Error al cerrar recursos: " + e.getMessage());
                e.printStackTrace();
            }
            con.cerrarConexion();
        }
        return email;
    }

    /**
     * Actualiza la información de un usuario existente.
     * @return true si el usuario se actualizó correctamente, false en caso contrario.
     */
    public boolean actualizarUsuario(int id, String nombre, String cedula, int perfil, int estadoCivil, String correo, int estadoUsuario) {
        boolean resultado = false;
        Conexion con = new Conexion();
        PreparedStatement pr = null;
        String sql = "UPDATE tb_usuario SET nombre_us = ?, cedula_us = ?, id_per = ?, id_est = ?, correo_us = ?, estado_us = ? WHERE id_us = ?";

        System.out.println("DEBUG: [Usuario.java] actualizarUsuario - Actualizando usuario ID: " + id);

        try {
            Connection connection = con.getConexion();
            if (connection == null) {
                System.out.println("ERROR: [Usuario.java] actualizarUsuario - No se pudo obtener la conexión a la base de datos.");
                return false;
            }
            pr = connection.prepareStatement(sql);
            pr.setString(1, nombre != null ? nombre.trim() : null);
            pr.setString(2, cedula != null ? cedula.trim() : null);
            pr.setInt(3, perfil);
            pr.setInt(4, estadoCivil);
            pr.setString(5, correo != null ? correo.trim() : null);
            pr.setInt(6, estadoUsuario);
            pr.setInt(7, id);

            resultado = pr.executeUpdate() == 1;
            System.out.println("DEBUG: [Usuario.java] actualizarUsuario - Resultado: " + resultado);

        } catch (SQLException ex) {
            System.out.println("ERROR: [Usuario.java] actualizarUsuario - Error SQL: " + ex.getMessage());
            ex.printStackTrace();
        } catch (Exception ex) {
            System.out.println("ERROR: [Usuario.java] actualizarUsuario - Error inesperado: " + ex.getMessage());
            ex.printStackTrace();
        } finally {
            try {
                if (pr != null) pr.close();
            } catch (SQLException e) {
                System.out.println("ERROR: [Usuario.java] actualizarUsuario - Error cerrando PreparedStatement: " + e.getMessage());
                e.printStackTrace();
            }
            con.cerrarConexion();
        }
        return resultado;
    }

    /**
     * Consulta todos los usuarios registrados en el sistema.
     * @return Una lista de objetos Usuario.
     */
    public List<Usuario> consultarTodosUsuarios() {
        List<Usuario> usuarios = new ArrayList<>();
        String sql = "SELECT u.id_us, u.nombre_us, u.cedula_us, u.correo_us, p.descripcion_per, ec.descripcion_est, u.estado_us, u.id_per, u.id_est " +
                     "FROM tb_usuario u " +
                     "JOIN tb_perfil p ON u.id_per = p.id_per " +
                     "JOIN tb_estadocivil ec ON u.id_est = ec.id_est ORDER BY u.id_us";
        Conexion con = new Conexion();
        ResultSet rs = null;
        PreparedStatement ps = null;

        System.out.println("DEBUG: [Usuario.java] consultarTodosUsuarios - Consultando todos los usuarios.");

        try {
            Connection connection = con.getConexion();
            if (connection == null) {
                System.out.println("ERROR: [Usuario.java] consultarTodosUsuarios - No se pudo obtener la conexión a la base de datos.");
                return usuarios;
            }
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Usuario u = new Usuario();
                u.setId(rs.getInt("id_us"));
                u.setNombre(rs.getString("nombre_us"));
                u.setCedula(rs.getString("cedula_us"));
                u.setCorreo(rs.getString("correo_us"));
                u.setPerfil(rs.getInt("id_per"));
                u.setEstadoCivil(rs.getInt("id_est"));
                u.setEstadoUsuario(rs.getInt("estado_us"));
                usuarios.add(u);
            }
            System.out.println("DEBUG: [Usuario.java] consultarTodosUsuarios - Usuarios encontrados: " + usuarios.size());
        } catch (SQLException e) {
            System.out.println("ERROR: [Usuario.java] consultarTodosUsuarios - Error SQL: " + e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            System.out.println("ERROR: [Usuario.java] consultarTodosUsuarios - Error inesperado: " + e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
            } catch (SQLException e) {
                System.out.println("ERROR: [Usuario.java] consultarTodosUsuarios - Error al cerrar recursos: " + e.getMessage());
                e.printStackTrace();
            }
            con.cerrarConexion();
        }
        return usuarios;
    }

    /**
     * Obtiene un ResultSet con la información de un usuario por su ID.
     * NOTA: Este método devuelve un ResultSet, la conexión debe cerrarse donde se use.
     * @param id El ID del usuario.
     * @return Un ResultSet con los datos del usuario o null si no se encuentra o hay un error.
     */
    public ResultSet obtenerUsuarioPorId(int id) {
        String sql = "SELECT id_us, nombre_us, cedula_us, correo_us, id_per, id_est, estado_us FROM tb_usuario WHERE id_us = ?";
        Conexion con = new Conexion(); // Se crea una nueva conexión aquí
        ResultSet rs = null;
        PreparedStatement ps = null;

        System.out.println("DEBUG: [Usuario.java] obtenerUsuarioPorId - Buscando usuario por ID: " + id);

        try {
            Connection connection = con.getConexion();
            if (connection == null) {
                System.out.println("ERROR: [Usuario.java] obtenerUsuarioPorId - No se pudo obtener la conexión a la base de datos.");
                return null;
            }
            ps = connection.prepareStatement(sql);
            ps.setInt(1, id);
            rs = ps.executeQuery();
            if(rs.next()) { // Mover rs.next() aquí para que el ResultSet esté en la primera fila si hay resultados
                System.out.println("DEBUG: [Usuario.java] obtenerUsuarioPorId - Usuario encontrado para ID: " + id);
                rs.beforeFirst(); // Resetear el cursor para que el JSP pueda leerlo desde el principio
            } else {
                System.out.println("DEBUG: [Usuario.java] obtenerUsuarioPorId - No se encontró usuario para ID: " + id);
                // Si no se encuentra, la conexión aún debe cerrarse en el finally
                // y el ResultSet debe ser null.
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                con.cerrarConexion();
                return null;
            }
        } catch (SQLException e) {
            System.out.println("ERROR: [Usuario.java] obtenerUsuarioPorId - Error SQL: " + e.getMessage());
            e.printStackTrace();
            rs = null; // Asegurarse de que rs sea null en caso de error
        } catch (Exception e) {
            System.out.println("ERROR: [Usuario.java] obtenerUsuarioPorId - Error inesperado: " + e.getMessage());
            e.printStackTrace();
            rs = null; // Asegurarse de que rs sea null en caso de error
        } finally {
            // NOTA: No cerramos el ResultSet y el PreparedStatement aquí si el ResultSet se va a devolver
            // La conexión 'con' debe cerrarse en el método que consume este ResultSet
            // Si hay un error, ya se asignó rs = null, y la conexión se cerró en el catch/if no encontrado.
        }
        return rs;
    }

    /**
     * Cambia el estado de un usuario (activo/bloqueado).
     * @param id El ID del usuario.
     * @param nuevoEstado El nuevo estado (0 para activo, 1 para bloqueado).
     * @return true si el estado se cambió exitosamente, false en caso contrario.
     */
    public boolean cambiarEstadoUsuario(int id, int nuevoEstado) {
        boolean resultado = false;
        Conexion con = new Conexion();
        PreparedStatement pr = null;
        String sql = "UPDATE tb_usuario SET estado_us = ? WHERE id_us = ?";

        System.out.println("DEBUG: [Usuario.java] cambiarEstadoUsuario - Cambiando estado para usuario ID: " + id + " a estado: " + nuevoEstado);

        try {
            Connection connection = con.getConexion();
            if (connection == null) {
                System.out.println("ERROR: [Usuario.java] cambiarEstadoUsuario - No se pudo obtener la conexión a la base de datos.");
                return false;
            }
            pr = connection.prepareStatement(sql);
            pr.setInt(1, nuevoEstado);
            pr.setInt(2, id);

            resultado = pr.executeUpdate() == 1;
            System.out.println("DEBUG: [Usuario.java] cambiarEstadoUsuario - Resultado: " + resultado);

        } catch (SQLException ex) {
            System.out.println("ERROR: [Usuario.java] cambiarEstadoUsuario - Error SQL: " + ex.getMessage());
            ex.printStackTrace();
        } catch (Exception ex) {
            System.out.println("ERROR: [Usuario.java] cambiarEstadoUsuario - Error inesperado: " + ex.getMessage());
            ex.printStackTrace();
        } finally {
            try {
                if (pr != null) pr.close();
            } catch (SQLException e) {
                System.out.println("ERROR: [Usuario.java] cambiarEstadoUsuario - Error cerrando PreparedStatement: " + e.getMessage());
                e.printStackTrace();
            }
            con.cerrarConexion();
        }
        return resultado;
    }
}
