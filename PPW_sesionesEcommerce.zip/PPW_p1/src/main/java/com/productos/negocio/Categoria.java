package com.productos.negocio;
import com.productos.datos.Conexion;
import java.sql.*;

public class Categoria {

    public String mostrarCategoria() {
        // Inicializa el combo con la etiqueta select, incluyendo id y required para que coincida con tu JSP
        // Es importante que el ID y el 'required' estén presentes para la interacción con el formulario.
        String combo = "<select id='cmbCategoria' name='cmbCategoria' required>";
        String sql = "SELECT * FROM tb_categoria";
        Conexion con = new Conexion(); // Instancia un nuevo objeto Conexion
        ResultSet rs = null;

        System.out.println("DEBUG: [Categoria.java] Intentando mostrar categorías. Consulta SQL: " + sql);

        try {
            // Llama al método Consulta de tu clase Conexion
            rs = con.Consulta(sql);

            if (rs != null) { // Verifica si el ResultSet no es nulo (la consulta pudo ejecutarse)
                System.out.println("DEBUG: [Categoria.java] Consulta ejecutada. Procesando resultados...");
                boolean foundCategories = false;
                while (rs.next()) {
                    // rs.getInt(1) para el ID de la categoría y rs.getString(2) para la descripción
                    combo += "<option value=\"" + rs.getInt(1) + "\">" + rs.getString(2) + "</option>";
                    foundCategories = true;
                }
                if (!foundCategories) {
                    System.out.println("DEBUG: [Categoria.java] ResultSet vacío. No se encontraron categorías en la base de datos.");
                    // Opción de fallback si no hay categorías
                    combo += "<option value='-2'>No hay categorías disponibles</option>";
                }
            } else {
                System.out.println("DEBUG: [Categoria.java] ResultSet es NULO. Esto indica un posible error en Conexion.Consulta() o la conexión a la base de datos.");
                // Opción de fallback si el ResultSet es nulo
                combo += "<option value='-1'>Error al conectar o consultar (ResultSet nulo)</option>";
            }
            combo += "</select>";
        } catch (SQLException e) {
            // IMPRIME LA TRAZA COMPLETA DEL ERROR: ¡Esto es vital para depurar!
            e.printStackTrace(); 
            System.out.println("DEBUG: [Categoria.java] SQL Error en Categoria.mostrarCategoria(): " + e.getMessage());
            // En caso de error SQL, devolvemos un combo con una opción de error
            combo = "<select id='cmbCategoria' name='cmbCategoria' required><option value='-1'>Error al cargar categorías</option></select>";
        } finally {
            // Es crucial cerrar el ResultSet para liberar recursos de la base de datos
            try {
                if (rs != null) {
                    rs.close();
                    System.out.println("DEBUG: [Categoria.java] ResultSet cerrado.");
                }
            } catch (SQLException e) {
                System.out.println("DEBUG: [Categoria.java] Error al cerrar ResultSet: " + e.getMessage());
                e.printStackTrace();
            }
            // La conexión 'con' es manejada por la clase Conexion; no la cerramos aquí explícitamente.
            // Asegúrate de que tu clase Conexion maneje el cierre de la conexión adecuadamente.
        }
        System.out.println("DEBUG: [Categoria.java] Finalizado el método mostrarCategoria(). Combo HTML generado: " + combo);
        return combo;
    }
}
