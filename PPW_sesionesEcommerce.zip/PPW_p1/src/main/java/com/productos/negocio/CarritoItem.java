package com.productos.negocio;

public class CarritoItem {
    private int idProducto;
    private String nombreProducto;
    private double precioUnitario;
    private int cantidad;

    public CarritoItem(int idProducto, String nombreProducto, double precioUnitario, int cantidad) {
        this.idProducto = idProducto;
        this.nombreProducto = nombreProducto;
        this.precioUnitario = precioUnitario;
        this.cantidad = cantidad;
    }

    // Getters
    public int getIdProducto() {
        return idProducto;
    }

    public String getNombreProducto() {
        return nombreProducto;
    }

    public double getPrecioUnitario() {
        return precioUnitario;
    }

    public int getCantidad() {
        return cantidad;
    }

    // Setters (para permitir cambios en cantidad)
    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public double getTotalItem() {
        return this.cantidad * this.precioUnitario;
    }
}
