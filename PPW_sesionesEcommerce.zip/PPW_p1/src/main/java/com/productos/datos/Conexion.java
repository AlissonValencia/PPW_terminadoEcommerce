package com.productos.datos;

import java.sql.*;

public class Conexion {

    private final String driver = "org.postgresql.Driver";
    private final String user = "postgres";
    private final String pwd = "1234";
    private final String cadena = "jdbc:postgresql://localhost:5432/bd_baloncesto";
    private Connection con;

    // Constructor
    public Conexion() {
        System.out.println("DEBUG: [Conexion.java] Constructor de Conexion llamado.");
        this.con = crearConexion();
    }

    // Crear conexión
    private Connection crearConexion() {
        try {
            System.out.println("DEBUG: [Conexion.java] Intentando cargar el driver: " + driver);
            Class.forName(driver); // Carga el driver de PostgreSQL
            System.out.println("DEBUG: [Conexion.java] Driver cargado exitosamente.");

            System.out.println("DEBUG: [Conexion.java] Intentando conectar a la base de datos: " + cadena);
            Connection newCon = DriverManager.getConnection(cadena, user, pwd);
            System.out.println("DEBUG: [Conexion.java] Conexión a la base de datos establecida exitosamente.");
            return newCon;
        } catch (ClassNotFoundException e) {
            System.out.println("ERROR: [Conexion.java] Driver JDBC no encontrado: " + e.getMessage());
            e.printStackTrace();
            return null;
        } catch (SQLException e) {
            System.out.println("ERROR: [Conexion.java] Error de SQL al crear la conexión: " + e.getMessage());
            e.printStackTrace();
            return null;
        } catch (Exception e) {
            System.out.println("ERROR: [Conexion.java] Error inesperado creando la conexión: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }

    // Obtener conexión activa
    public Connection getConexion() {
        // Verifica si la conexión es nula o está cerrada, e intenta recrearla si es necesario
        try {
            if (this.con == null || this.con.isClosed()) {
                System.out.println("DEBUG: [Conexion.java] La conexión está nula o cerrada. Intentando recrearla.");
                this.con = crearConexion();
            }
        } catch (SQLException e) {
            System.out.println("ERROR: [Conexion.java] Error al verificar el estado de la conexión: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
        return this.con;
    }

    // Ejecutar sentencias INSERT, UPDATE, DELETE
    public String Ejecutar(String sql) {
        Connection currentCon = getConexion();
        if (currentCon == null) {
            System.out.println("ERROR: [Conexion.java] Ejecutar - No hay conexión a la base de datos.");
            return "Error: No hay conexión a la base de datos.";
        }
        System.out.println("DEBUG: [Conexion.java] Ejecutando SQL (INSERT/UPDATE/DELETE): " + sql);
        try (Statement st = currentCon.createStatement()) {
            st.execute(sql);
            System.out.println("DEBUG: [Conexion.java] SQL ejecutado exitosamente.");
            return "Datos insertados"; // Este mensaje es genérico, podría ser "Operación exitosa"
        } catch (SQLException ex) {
            System.out.println("ERROR: [Conexion.java] Error al ejecutar SQL (INSERT/UPDATE/DELETE): " + ex.getMessage());
            ex.printStackTrace();
            return "Error al ejecutar SQL: " + ex.getMessage();
        } catch (Exception ex) {
            System.out.println("ERROR: [Conexion.java] Error inesperado al ejecutar SQL (INSERT/UPDATE/DELETE): " + ex.getMessage());
            ex.printStackTrace();
            return "Error inesperado al ejecutar SQL: " + ex.getMessage();
        }
    }

    // Ejecutar consultas SELECT
    public ResultSet Consulta(String sql) {
        Connection currentCon = getConexion();
        if (currentCon == null) {
            System.out.println("ERROR: [Conexion.java] Consulta - No hay conexión a la base de datos para ejecutar la consulta.");
            return null;
        }
        System.out.println("DEBUG: [Conexion.java] Ejecutando SQL (SELECT): " + sql);
        try {
            Statement st = currentCon.createStatement();
            ResultSet rs = st.executeQuery(sql);
            System.out.println("DEBUG: [Conexion.java] Consulta SELECT ejecutada exitosamente.");
            return rs;
        } catch (SQLException ex) {
            System.out.println("ERROR: [Conexion.java] Error al ejecutar consulta SELECT: " + ex.getMessage());
            ex.printStackTrace();
            return null;
        } catch (Exception ex) {
            System.out.println("ERROR: [Conexion.java] Error inesperado al ejecutar consulta SELECT: " + ex.getMessage());
            ex.printStackTrace();
            return null;
        }
    }

    // Obtener PreparedStatement para consultas seguras
    public PreparedStatement getPreparedStatement(String sql) throws SQLException {
        Connection currentCon = getConexion();
        if (currentCon == null) {
            throw new SQLException("No hay conexión a la base de datos para preparar la sentencia.");
        }
        System.out.println("DEBUG: [Conexion.java] Preparando sentencia SQL: " + sql);
        return currentCon.prepareStatement(sql);
    }

    // Cerrar la conexión
    public void cerrarConexion() {
        try {
            if (con != null && !con.isClosed()) {
                con.close();
                System.out.println("DEBUG: [Conexion.java] Conexión a la base de datos cerrada correctamente.");
            }
        } catch (SQLException e) {
            System.out.println("ERROR: [Conexion.java] Error al cerrar la conexión: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Probar conexión (solo para main)
    private void probarConexion() {
        if (con != null) {
            System.out.println("DEBUG: [Conexion.java] Conexión establecida correctamente.");
        } else {
            System.out.println("DEBUG: [Conexion.java] No se pudo establecer la conexión.");
        }
    }

    // Probar consulta simple (solo para main)
    public void probarConsulta() {
        try (Statement st = con.createStatement();
             ResultSet rs = st.executeQuery("SELECT 1")) {
            if (rs.next()) {
                System.out.println("DEBUG: [Conexion.java] Consulta exitosa. Resultado: " + rs.getInt(1));
            } else {
                System.out.println("DEBUG: [Conexion.java] Consulta sin resultados.");
            }
        } catch (Exception e) {
            System.out.println("ERROR: [Conexion.java] Error en la consulta de prueba: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Main para probar conexión y consulta
    public static void main(String[] args) {
        Conexion c = new Conexion();
        c.probarConexion();
        c.probarConsulta();
        c.cerrarConexion();
    }
}
